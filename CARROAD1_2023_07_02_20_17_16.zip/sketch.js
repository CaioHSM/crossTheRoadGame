


  

function setup() {
  createCanvas(550, 400);
  somTrilha.loop();
}

function draw() {
  background(imagenEstrada);
  showCar();
  showPlayer();
  movCar();
  movPlayer();
  resetCars();
  verCollide();
  showPoints();
  points();
}

