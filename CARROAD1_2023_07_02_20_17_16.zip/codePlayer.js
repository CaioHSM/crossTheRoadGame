//PLAYER
let yPlayer = 366;
let XPlayer = 100;
let colisao = false;
let playerPoints = 0;
////////////////////INICIO/////////////////////////////////
function showPlayer(){
  image(imgPlayer,XPlayer,yPlayer,33,30);
  
  
}
function movPlayer(){
if (keyIsDown(UP_ARROW)){
  yPlayer -= 3;
 }
  if ( keyIsDown(DOWN_ARROW)){
    if (canMove()){
    yPlayer += 3;
    }
  }
}

function verCollide(){
  //collideRectcircle(x1, y1, width1, height1, cx, cy, diameter)
  for ( let i = 0; i<imgCars.length; i+=1){
    colisao = collideRectCircle(xCars[i], yCars[i], compCars, altCars, XPlayer, yPlayer, 15 );
    if (colisao){
      resetPosition();
      somColi.play();
      if (playerPointsGreaterThanZero()){
        playerPoints -=1;
      }
    }
  }
}
function resetPosition(){
  yPlayer = 366;
}
function showPoints(){
  textAlign(CENTER)
  textSize(25);
  fill (0,255,0)
  text(playerPoints, width/6,25); 
  
}
function points(){
  if(yPlayer < 15){
  playerPoints +=1;
    somPoints.play();
    resetPosition();
  }
}
function playerPointsGreaterThanZero(){
return playerPoints > 0;
}
function canMove(){
  return yPlayer < 366;
}
