/////////////////////////codeCars///////////////////////////
//LISTAS
let xCars = [600,600,600,600,600,600];
let yCars = [42,97,150,204,258,312];
let velCars = [2, 2.5, 3.2, 5, 3.3, 2,3];
let compCars = 50;
let altCars = 40;

////////////////////////////////////INICIO///////////////////////////
function showCar(){
  for(let i =0; i < imgCars.length; i+= 1)
  image(imgCars[i],xCars[i],yCars[i],compCars,altCars);
  
}
function movCar(){
   for(let i =0; i < imgCars.length; i+= 1){
  xCars[i] -=velCars[i];  
   }
}
function resetCars(){
   for(let i =0; i < imgCars.length; i+= 1){
  if (passouTodaAtela(xCars[i])){
    xCars[i] = 600;
  
   }
  }
}
function passouTodaAtela(xCar){
  return xCar < - 50;
}